            <nav>
                <ul>
                    <li><a href="about.php"> О НАС </a></li>
                    <li><a href="portfolio.php"> ПОРТФОЛИО </a></li>
                    <li><a href="skillsoft.php"> SKILL SOFT </a></li>
                    <li><a href="ssilki.php"> ССЫЛКИ </a></li>
                    <li><a href="contact.php"> КОНТАКТЫ </a></li>
                </ul>    
            </nav>