

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Максим';
 $surname = 'Викторович';
 $city = 'Майкоп';
 $age = 36;
?>


<?php
include 'main.php';
?>

