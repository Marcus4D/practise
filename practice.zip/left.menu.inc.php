  
        <p align="center" class="title">МЕНЮ SOFT</p>
                     <nav class="leftmenuinc">
               
                   <a href="program/keylogger.py"> KEYLOGGER </a><br>
                   <a href="program/cmds.html"> PHASER </a><br>
                   <a href="#"> FORENSICS </a><br>
                   <a href="#"> BRUTOS </a><br>
                   <a href="#"> BACKDOOR</a><br>
                   <input type="button" value="Launch Installer" onclick="window.open('file:///S:/Test/Test.bat')" />
            </nav>

<p align="center" class="title2">Рассылка</p>
<div class="formm" width="80%">	
<p class='form3'> Подпишитесь на нашу рассылку и получите софт</p>
<form name="SR_form" method="post" target="_blank" action="#" onsubmit="return SR_submit(this)">
<input type=hidden name=version value="1">
<input type=hidden name=tid value="34769">
<input type=hidden name=uid value="27025">
<input type=hidden name=charset value="windows-1251">
<input type=hidden name=lang value="1">
<input type=hidden name="did[]" value="9267">
 <p class='form1'> Ваше имя:
 <input type="text" name="field_name_first" size=23 value='' maxlength=50 style='border: 1px #c1c1c1 solid; font-family: Verdana; font-size: 11px; width:120px; color:#424242;'></p>
<p class='form1'> Email:
<input type=text name="field_email" size=23 value='' maxlength=50   style='margin:0px; padding:0px; border: 1px #c1c1c1 solid; font-family: Verdana; font-size: 11px; width:120px; color:#424242;'></p>
<p style='margin:5px;margin-top:10px; padding:0px;'>
<input type="submit" name="SR_submitButton" value='ПОДПИСАТЬ' style=' font-family: Verdana, sans-serif; border:1px gray solid; font-size: 11px; width:120px; height:19px;   background-Color:#f6f6f6; color:#424242; font-weight:bold; margin-left:10px;' >
</p>
</form>
</div>
        
                 